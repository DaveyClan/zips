# uservar.py

import os
import xbmcaddon

# ===== Core Identity =====
ADDON_ID = 'plugin.program.daveyclanwizard'
ADDON = xbmcaddon.Addon(ADDON_ID)

ADDONTITLE = '[COLOR orchid][B]DAVEYCLAN[/B][/COLOR]'
BUILDERNAME = '[COLOR white]DaveyClan[/COLOR]'

PATH = ADDON.getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'art')

# ===== Appearance =====
COLOR1 = 'orchid'
COLOR2 = 'white'

HEADERTYPE = 'Image'
HEADERMESSAGE = ADDONTITLE
HEADERIMAGE = os.path.join(ART, 'header.png')
BACKGROUND = os.path.join(ART, 'background.jpg')

THEME1 = '[COLOR {0}]%s[/COLOR]'.format(COLOR1)
THEME2 = '[COLOR {0}]%s[/COLOR]'.format(COLOR2)
THEME3 = '[COLOR {0}]%s[/COLOR]'.format(COLOR1)
THEME4 = '[COLOR {0}]Current Build: %s[/COLOR]'.format(COLOR1)
THEME5 = '[COLOR {0}]Current Theme: %s[/COLOR]'.format(COLOR1)

HIDESPACERS = 'No'

# ===== Contact =====
HIDECONTACT = 'No'
CONTACT = (
    "KEEP CALM and EXPECT US\n\n"
    "Whitehat...\n"
    "Greyhat...\n"
    "Blackhat...\n"
    "Bluehat...\n"
    "Greenhat..."
)

CONTACTICON = os.path.join(ART, 'qricon.png')
CONTACTFANART = ''

# ===== Build / Update Files =====
BUILDFILE = 'https://raw.githubusercontent.com/DaveyClan/Builds/main/Builds/builds.txt'
APKFILE = BUILDFILE
YOUTUBETITLE = ''
YOUTUBEFILE = ''
ADDONFILE = ''
ADVANCEDFILE = ''
WIZARDFILE = BUILDFILE

UPDATECHECK = 0
AUTOUPDATE = 'Yes'
AUTOINSTALL = 'Yes'
NOTIFICATION = 'Yes'
ENABLE = 'Yes'

REPOADDONXML = ''
REPOZIPURL = ''

# ===== Exclusions =====
EXCLUDES = [
    ADDON_ID,
    'repository.daveyclan',
    'script.module.kodi-six'
]

# ===== Caching =====
CACHETEXT = 'Yes'
CACHEAGE = 30

# ===== Icons (Menu Icons) =====
ICONBUILDS   = os.path.join(ART, 'iconbuilds.png')
ICONMAINT    = os.path.join(ART, 'iconmaint.png')
ICONAPK      = os.path.join(ART, 'iconapk.png')
ICONADDONS   = os.path.join(ART, 'iconaddons.png')
ICONYOUTUBE  = os.path.join(ART, 'iconyoutube.png')
ICONSAVE     = os.path.join(ART, 'iconsave.png')
ICONTRAKT    = os.path.join(ART, 'icontrakt.png')
ICONREAL     = os.path.join(ART, 'iconreal.png')
ICONLOGIN    = os.path.join(ART, 'iconlogin.png')
ICONCONTACT  = os.path.join(ART, 'iconcontact.png')
ICONSETTINGS = os.path.join(ART, 'iconsettings.png')
