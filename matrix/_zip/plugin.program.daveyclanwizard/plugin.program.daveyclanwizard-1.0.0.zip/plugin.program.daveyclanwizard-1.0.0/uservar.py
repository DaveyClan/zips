# uservar.py

import os
import xbmc
import xbmcaddon
import xbmcvfs

# ===== Core Identity =====
ADDON_ID = 'plugin.program.daveyclanwizard'
ADDONTITLE = '[COLOR orchid][B]DAVEYCLAN[/B][/COLOR]'
BUILDERNAME = '[COLOR white]DaveyClan[/COLOR]'

# ===== Kodi Paths =====
ADDON = xbmcaddon.Addon(ADDON_ID)
PATH = ADDON.getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'art')

# ===== Appearance =====
COLOR1 = 'orchid'
COLOR2 = 'white'
HEADERTYPE = 'Image'   # REQUIRED by notify.py

THEME1 = '[COLOR {0}]%s[/COLOR]'.format(COLOR1)
THEME2 = '[COLOR {0}]%s[/COLOR]'.format(COLOR2)
THEME3 = '[COLOR {0}]%s[/COLOR]'.format(COLOR1)
THEME4 = '[COLOR {0}]Current Build: %s[/COLOR]'.format(COLOR1)
THEME5 = '[COLOR {0}]Current Theme: %s[/COLOR]'.format(COLOR1)

# ===== Exclusions =====
EXCLUDES = [
    ADDON_ID,
    'repository.daveyclan',
    'script.module.kodi-six'
]

# ===== Build Files =====
BUILDFILE    = 'https://raw.githubusercontent.com/DaveyClan/Builds/main/Builds/builds.txt'
APKFILE      = BUILDFILE
YOUTUBEFILE  = ''
ADDONFILE    = ''
ADVANCEDFILE = ''
WIZARDFILE   = BUILDFILE

# ===== Update Control =====
UPDATECHECK = 0
AUTOUPDATE  = 'Yes'
NOTIFICATION = 'Yes'
ENABLE = 'Yes'
AUTOINSTALL = 'Yes'

# ===== Repo (optional) =====
REPOADDONXML = ''
REPOZIPURL   = ''

# ===== Include Options =====
INCLUDEVIDEO   = 'Yes'
INCLUDEALL     = 'Yes'
INCLUDEGAIA    = 'No'
INCLUDESEREN   = 'No'
INCLUDETHECREW = 'Yes'
INCLUDEHOMELANDER = 'No'
INCLUDEMORIA   = 'No'
SHOWADULT      = 'No'

# ===== Wizard Settings =====
WIZDEBUGGING  = 'No'
DEBUGLEVEL    = 1
ENABLEWIZLOG  = 'Yes'
CLEANWIZLOG   = 'Yes'
CLEANWIZLOGBY = 'Days'
CLEANDAYS     = 7
CLEANSIZE     = 500
CLEANLINES    = 500
INSTALLMETHOD = 'Auto'
DEVELOPER     = 'No'
THIRDPARTY    = 'Yes'
THIRD1NAME    = ''
THIRD1URL     = ''
THIRD2NAME    = ''
THIRD2URL     = ''
THIRD3NAME    = ''
THIRD3URL     = ''

# ===== Caching =====
CACHETEXT = 'Yes'
CACHEAGE  = 30

# ===== Contact =====
HIDECONTACT = 'No'
CONTACT = (
    "KEEP CALM and EXPECT US\n\n"
    "Whitehat...\n"
    "Greyhat...\n"
    "Blackhat...\n"
    "Bluehat...\n"
    "Greenhat..."
)

CONTACTICON   = os.path.join(ART, 'qricon.png')
CONTACTFANART = ''
