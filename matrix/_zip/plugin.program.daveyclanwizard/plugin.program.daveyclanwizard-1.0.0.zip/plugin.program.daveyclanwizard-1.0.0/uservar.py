# uservar.py
import os

# ===== Paths =====
HOME = os.path.expanduser("~")
PATH = os.path.join(HOME, "addon_data")
ART = os.path.join(PATH, "resources", "art")

# ===== User Editable Variables =====
ADDON_ID = 'plugin.program.daveyclanwizard'
ADDONTITLE = "[COLOR orchid][B]DAVEYCLAN[/B][/COLOR]"
BUILDERNAME = "[COLOR white]DaveyClan[/COLOR]"
EXCLUDES = [ADDON_ID, 'repository.daveyclan', 'script.module.kodi-six']

# ===== Build & Update URLs =====
BUILDFILE      = 'https://raw.githubusercontent.com/DaveyClan/Builds/main/Builds/builds.txt'
APKFILE        = 'BUILDFILE'
YOUTUBEFILE    = ''
ADDONFILE      = ''
ADVANCEDFILE   = 'advancedsettings.xml'
AUTOUPDATE     = 'Yes'
WIZARDFILE     = BUILDFILE
REPOADDONXML   = ''
REPOZIPURL     = ''
UPDATECHECK    = 0


# ===== Include Options =====
INCLUDEVIDEO   = 'Yes'
INCLUDEALL     = 'Yes'
INCLUDEGAIA    = 'No'
INCLUDESEREN   = 'No'
INCLUDETHECREW = 'Yes'
INCLUDEHOMELANDER = 'No'
INCLUDEMORIA   = 'No'
SHOWADULT      = 'No'

# ===== Logging / Wizard Settings =====
WIZDEBUGGING   = 'No'
DEBUGLEVEL     = 1
ENABLEWIZLOG   = 'Yes'
CLEANWIZLOG    = 'Yes'
CLEANWIZLOGBY  = 'Days'
CLEANDAYS      = 7
CLEANSIZE      = 500
CLEANLINES     = 500
INSTALLMETHOD  = 'Auto'
DEVELOPER      = 'No'
THIRDPARTY     = 'Yes'
THIRD1NAME     = ''
THIRD1URL      = ''
THIRD2NAME     = ''
THIRD2URL      = ''
THIRD3NAME     = ''
THIRD3URL      = ''
NOTIFICATION   = 'Yes'
ENABLE         = 'Yes'
AUTOINSTALL    = 'Yes'

# ===== Caching =====
CACHETEXT = 'Yes'
CACHEAGE  = 30  # in minutes

# ===== Menu Colors / Themes =====
COLOR1 = 'orchid'
COLOR2 = 'white'
THEME1 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'
THEME2 = f'[COLOR {COLOR2}][/COLOR {COLOR2}]'
THEME3 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'
THEME4 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'
THEME5 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'

# ===== Contact Page =====
HIDECONTACT = 'No'
CONTACT = (
    "KEEP CALM and EXPECT US\n"
    "Whitehat...\n"
    "Greyhat...\n"
    "Blackhat...\n"
    "Bluehat...\n"
    "Greenhat..."
)
CONTACTFANART = os.path.join(ART, 'qricon.png')  # default contact icon
