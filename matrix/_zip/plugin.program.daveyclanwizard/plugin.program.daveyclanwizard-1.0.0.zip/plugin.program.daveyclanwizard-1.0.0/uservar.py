# useravr.py
# Safe version for Kodi – uses your branding, build URLs, and menu colors

import os

# ===== Paths =====
PATH = os.path.join(os.path.expanduser("~"), "addon_data")  # addon_data path
ART = os.path.join(PATH, "resources", "art")  # folder for fanart/icons

# ===== User Editable Variables =====
ADDON_ID = 'plugin.program.daveyclanwizard'
ADDONTITLE = "[COLOR orchid][B]DAVEYCLAN[/B][/COLOR]"
BUILDERNAME = "[COLOR white]DaveyClan[/COLOR]"
EXCLUDES = [ADDON_ID, 'repository.daveyclan', 'script.module.kodi-six']


# Enable/disable caching for text files
CACHETEXT = 'Yes'
CACHEAGE = 30  # in minutes

# ===== Build & Update URLs =====
BUILDFILE = 'https://raw.githubusercontent.com/daveyclan/builds/main/builds/builds.txt'
APKFILE = 'https://raw.githubusercontent.com/daveyclan/builds/main/builds/builds.txt'
YOUTUBEFILE = ''
ADDONFILE = ''

# ===== Menu Colors / Themes =====
COLOR1 = 'orchid'
COLOR2 = 'white'
THEME1 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'
THEME2 = f'[COLOR {COLOR2}][/COLOR {COLOR2}]'
THEME3 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'
THEME4 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'
THEME5 = f'[COLOR {COLOR1}][/COLOR {COLOR2}]'

# ===== Contact Page =====
HIDECONTACT = 'No'
CONTACT = (
    "KEEP CALM and EXPECT US\n"
    "Whitehat...\n"
    "Greyhat...\n"
    "Blackhat...\n"
    "Bluehat...\n"
    "Greenhat..."
)
CONTACTFANART = os.path.join(ART, 'qricon.png')  # default contact icon

# ===== Auto Update Options =====
AUTUPDATE = 'no'
WIZARDFILE = BUILDFILE

# ===== Functions =====
def print_build_info():
    print("Addon ID:", ADDON_ID)
    print("Builder Name:", BUILDERNAME)
    print("Build Info URL:", BUILDFILE)
    print("Cache Enabled:", CACHETEXT)
    print("Cache Age (min):", CACHEAGE)
    print("APK File:", APKFILE)
    print("YouTube File:", YOUTUBEFILE)
    print("Addon File:", ADDONFILE)

def get_contact_info():
    if HIDECONTACT.lower() == 'no':
        return CONTACT
    return ''

# ===== Example Execution =====
if __name__ == "__main__":
    print_build_info()
    contact_msg = get_contact_info()
    if contact_msg:
        print("\nContact Page Info:\n", contact_msg)
